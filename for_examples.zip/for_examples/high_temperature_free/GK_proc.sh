nohup  ./Green_Kubo  10   current_correlator.txt      covariance_matrix.txt     ./log_files  const_GK.txt   &
