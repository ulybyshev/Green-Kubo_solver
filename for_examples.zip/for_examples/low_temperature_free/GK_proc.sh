nohup ./Green_Kubo  40  current_correlator.txt      covariance_matrix.txt    ./log_files  const_GK.txt   &
