cd /Users/ulybyshev/Calculations/Square_hubbard/example_run
rm -rf log_files
mkdir log_files
/Users/ulybyshev/Documents/git_projects/Green-Kubo_solver/bin/gk_solver  -t 10   -c   /Users/ulybyshev/Calculations/Square_hubbard/example_run/correlator_data/correlator_data.txt        -m      /Users/ulybyshev/Calculations/Square_hubbard/example_run/correlator_data/cov_matrix_data.txt          -o     /Users/ulybyshev/Calculations/Square_hubbard/example_run/log_files           -p       /Users/ulybyshev/Calculations/Square_hubbard/example_run/const_GK.txt   
