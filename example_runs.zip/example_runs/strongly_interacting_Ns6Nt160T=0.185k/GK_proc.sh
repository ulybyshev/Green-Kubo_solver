cd /Users/ulybyshev/Calculations/Square_hubbard/example_runs/strongly_interacting_Ns6Nt160T=0.185k/
rm -rf  ./logs
mkdir ./logs
nohup /Users/ulybyshev/Documents/git_projects/Green-Kubo_solver/bin/gk_solver  -t  80  -c  /Users/ulybyshev/Calculations/Square_hubbard/example_runs/strongly_interacting_Ns6Nt160T=0.185k/correlator_data/correlator_data.txt  -m   /Users/ulybyshev/Calculations/Square_hubbard/example_runs/strongly_interacting_Ns6Nt160T=0.185k/correlator_data/cov_matrix_data.txt   -o   /Users/ulybyshev/Calculations/Square_hubbard/example_runs/strongly_interacting_Ns6Nt160T=0.185k/logs   -p   /Users/ulybyshev/Calculations/Square_hubbard/example_runs/strongly_interacting_Ns6Nt160T=0.185k/const_GK.txt   & 
