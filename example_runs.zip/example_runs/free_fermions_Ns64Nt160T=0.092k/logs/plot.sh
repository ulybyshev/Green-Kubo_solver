gnuplot plot_delta.gnu
gnuplot plot_rho.gnu
