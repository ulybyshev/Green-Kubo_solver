cd /Users/ulybyshev/Calculations/Square_hubbard/example_runs/free_fermions_Ns64Nt160T=0.092k/
rm -rf  ./logs
mkdir ./logs
nohup /Users/ulybyshev/Documents/git_projects/Green-Kubo_solver/bin/gk_solver  -a  -t  80  -c  /Users/ulybyshev/Calculations/Square_hubbard/example_runs/free_fermions_Ns64Nt160T=0.092k/correlator_data/correlator_data.txt    -m   /Users/ulybyshev/Calculations/Square_hubbard/example_runs/free_fermions_Ns64Nt160T=0.092k/correlator_data/cov_matrix_data.txt     -o   /Users/ulybyshev/Calculations/Square_hubbard/example_runs/free_fermions_Ns64Nt160T=0.092k/logs  -p    /Users/ulybyshev/Calculations/Square_hubbard/example_runs/free_fermions_Ns64Nt160T=0.092k/const_GK.txt       & 
