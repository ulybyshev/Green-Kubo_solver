cd /Users/ulybyshev/Calculations/Square_hubbard/example_runs/strongly_interacting_Hubbard_Coulomb/
rm -rf  ./logs
mkdir ./logs
nohup /Users/ulybyshev/Documents/git_projects/Green-Kubo_solver/bin/gk_solver  -t  80   -c  /Users/ulybyshev/Calculations/Square_hubbard/example_runs/strongly_interacting_Hubbard_Coulomb/correlator_data/full_data.txt     -o   /Users/ulybyshev/Calculations/Square_hubbard/example_runs/strongly_interacting_Hubbard_Coulomb/logs   &
